var searchData=
[
  ['gender_0',['gender',['../class_customer.html#aef01c92fcc53997598304b8dfee58afb',1,'Customer']]]
];
