var searchData=
[
  ['selectedsize_0',['selectedSize',['../class_product.html#a92a34f8f8f4d4d14594149f41a88b126',1,'Product::selectedSize'],['../mainwindow_8cpp.html#a7ad77c340749ae1aaaf0af5a9151c641',1,'selectedSize:&#160;mainwindow.cpp']]],
  ['surname_1',['surname',['../class_customer.html#ae69795230c6f3b24ff9711c844a7df4f',1,'Customer']]]
];
