var searchData=
[
  ['user_0',['user',['../mainwindow_8cpp.html#aa0812c602c9aed2b5356027b89d2387f',1,'mainwindow.cpp']]]
];
