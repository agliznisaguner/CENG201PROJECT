var searchData=
[
  ['favorites_0',['favorites',['../class_customer.html#ac85b2f125ec509fe075081b9b83d8485',1,'Customer::favorites'],['../customer_8cpp.html#ad78e5edfcf8ece0a3338d611ed6610b3',1,'favorites:&#160;customer.cpp']]],
  ['female_1',['Female',['../customer_8h.html#a3667e3c5ec056737c8789615a989324fab719ce180ec7bd9641fece2f920f4817',1,'customer.h']]]
];
