var searchData=
[
  ['name_0',['name',['../class_customer.html#a0f39144a10d4b9ec5caddd9cbcdd8425',1,'Customer']]]
];
