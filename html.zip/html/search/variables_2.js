var searchData=
[
  ['favorites_0',['favorites',['../class_customer.html#ac85b2f125ec509fe075081b9b83d8485',1,'Customer::favorites'],['../customer_8cpp.html#ad78e5edfcf8ece0a3338d611ed6610b3',1,'favorites:&#160;customer.cpp']]]
];
