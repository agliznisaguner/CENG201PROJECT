var searchData=
[
  ['addcart_0',['addCart',['../class_customer.html#a0bcc983a542d1c72a16e5114c062c2d1',1,'Customer']]],
  ['addcarttopreviousorders_1',['addCartToPreviousOrders',['../class_customer.html#a463e800276d15f93f4bdf0380c85f374',1,'Customer']]],
  ['addcomment_2',['addComment',['../class_product.html#a52fa3f706eb363955c66cdaf49864ac1',1,'Product']]],
  ['addfavorite_3',['addFavorite',['../class_customer.html#a6c789c723558bc995d894822e6d5adbe',1,'Customer']]],
  ['addpoint_4',['addPoint',['../class_customer.html#a147d5e7b7cd095a8e227e9e081f529a2',1,'Customer::addPoint()'],['../class_receipt.html#ae6ca2c1eaae3fef2fc64b2b8262bd69a',1,'Receipt::addPoint()']]],
  ['addproduct_5',['addProduct',['../class_cart.html#a5491333fdcb2dc698815a97b3e4ce88c',1,'Cart']]],
  ['applydiscount_6',['applyDiscount',['../class_payment.html#ab498e591df6136b3f58b4cddfefd1486',1,'Payment']]]
];
