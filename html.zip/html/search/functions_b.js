var searchData=
[
  ['savecomments_0',['saveComments',['../class_product.html#ae2edf37c6ba2f88dcd05751e1822d009',1,'Product']]],
  ['savefavorites_1',['saveFavorites',['../class_customer.html#a479946fdfcbef1f32f6ff96d42bc0acc',1,'Customer']]],
  ['savepreviousorders_2',['savePreviousOrders',['../class_customer.html#a9f2c2576be53f6b004cf964ad4f0a2aa',1,'Customer']]],
  ['setcomments_3',['setComments',['../class_product.html#a512fab756ec62298b25301934ea8c0aa',1,'Product']]],
  ['setcost_4',['setCost',['../class_product.html#a086e4cebaa0b85e5df34fbd655cc3046',1,'Product']]],
  ['setdiscount_5',['setDiscount',['../class_payment.html#a632eb5701729b2402e11e09b775cc442',1,'Payment']]],
  ['setexplanation_6',['setExplanation',['../class_product.html#a102b1633f5b8a1d7cf80d1d88e485c86',1,'Product']]],
  ['setfavorites_7',['setFavorites',['../class_customer.html#af43c0776f70c0c63592c5e7186db9a5a',1,'Customer']]],
  ['setid_8',['setId',['../class_product.html#a9abd9d0f0e801b29316b4d8f33c3ed62',1,'Product']]],
  ['setlikecount_9',['setLikeCount',['../class_product.html#a306565cb5e79b7f03c9013ec9ce274a1',1,'Product']]],
  ['setpicturepath_10',['setPicturePath',['../class_product.html#aa2155966b66d29e39653990ccb794cc9',1,'Product']]],
  ['setpreviousorders_11',['setPreviousOrders',['../class_customer.html#ab152c9ca54ca44a54e638ce049423ccc',1,'Customer']]],
  ['setselectedsize_12',['setSelectedSize',['../class_product.html#a10a5da607128b017c781cc55355039d7',1,'Product']]],
  ['sizetostring_13',['sizeToString',['../mainwindow_8cpp.html#a1f7e58b126417250cd4b6568a76e10da',1,'mainwindow.cpp']]]
];
