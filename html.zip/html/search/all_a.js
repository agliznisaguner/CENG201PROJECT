var searchData=
[
  ['name_0',['name',['../class_customer.html#a0f39144a10d4b9ec5caddd9cbcdd8425',1,'Customer']]],
  ['nodiscount_1',['NoDiscount',['../payment_8h.html#a3e64c895f5ae011093af5a9d75badafeadac59e6bba6e83dc21f1d5649b905a9c',1,'payment.h']]]
];
