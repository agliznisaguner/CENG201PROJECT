var searchData=
[
  ['hasinpreviousorders_0',['hasInpreviousOrders',['../class_customer.html#a8f58484aaed011914d86cb9adcc97d31',1,'Customer']]],
  ['haslikedproduct_1',['hasLikedProduct',['../class_customer.html#a94ede2b3e36d48d0274962030b3867b4',1,'Customer']]]
];
