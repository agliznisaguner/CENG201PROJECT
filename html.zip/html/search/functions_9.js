var searchData=
[
  ['payment_0',['Payment',['../class_payment.html#a3ac494355b87beb0957f39b8dbe35b3a',1,'Payment']]],
  ['product_1',['Product',['../class_product.html#a847c1d85e67ce387166a597579a55135',1,'Product::Product()'],['../class_product.html#a2cf420feac71d325b7355e1757cdb2e7',1,'Product::Product(int id, QString picturePath, QString explanation, double cost, int likeCount)'],['../class_product.html#a747c19f4ba80038a6ea00a10525a5711',1,'Product::Product(const Product &amp;temp)']]]
];
