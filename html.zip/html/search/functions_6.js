var searchData=
[
  ['likeproduct_0',['likeProduct',['../class_customer.html#a7c4711f1ec523f0b1d66bb262bae4159',1,'Customer::likeProduct()'],['../class_product.html#a44cd84e2465e75a9af1f030665e51532',1,'Product::likeProduct()']]]
];
