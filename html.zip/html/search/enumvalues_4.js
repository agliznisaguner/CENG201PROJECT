var searchData=
[
  ['nodiscount_0',['NoDiscount',['../payment_8h.html#a3e64c895f5ae011093af5a9d75badafeadac59e6bba6e83dc21f1d5649b905a9c',1,'payment.h']]]
];
